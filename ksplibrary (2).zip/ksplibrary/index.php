<!DOCTYPE html>
<html lang="en">
<link href="css/myproject.css" rel="stylesheet">
<head>
    <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
       <link rel="shortcut icon" href="images/kpoly.jpeg">
    <title>Kano State Polytechnic</title>  
   </head>
<body>
    <div class="head">
      <ul>
   <a href="adminlogin.php"><img src="images/kpoly.jpeg" class="pic"> </a> 
     <li><a href="adminlogin2.php"><h3>PROJECTS</h3></a></li> 
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
       <li><a href="about.php">About Us</a></li>
       <li><a href="login.php">Students</a></li>
       <li><a href="teacherslogin.php"> Supervisors</a></li>      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
       <a href="https://project-topic-name-70pw.glide.page/"> <li><input type="Submit" value="Project Verification"></li></a>
       </ul>
       <div class="line">
       </div>
    </div><br>
    <div class="first">
       <br>
        <div class="one">
           <div class="text">
              <br>
               <h1>New & <br>Trending</h1>
               <br>
               <h6>Explore new projects </h6>            
           </div>            
        </div>
          <div class="two">
         <a href="notice.php"> <img src="images/books.jpg" alt=""></a>             
        </div>
         <div class="three"><br>
           <br>
           <div class="write">
              <h6> Author of the week</h6>
           </div>
            <a href="notice.php"><img src="images/project%201.jpg" alt=""></a>            
        </div>
          <div class="four">
           <br>
           <br>
           <div class="write">
              <h6> Author of the week</h6>
           </div>
          <a href="pdf/PROJECT%20UPLOAD%20SYSTEM%20(Correction).pdf">  <img src="images/project%202.jpg" alt=""></a>            
        </div>
        <div class="divide"></div>
        <br>
        <br>
        <div class="five">
        <br>
        <img src="images/55.jpg" alt="">
          <h6> &#9733; &#9733; &#9733; &#9733; &#9733;<br> Updated Project Writeup</h6>
         <h5>By M. Khadija Mahmoud</h5>
          <br>
          <a href="pdf/UPDTED%20PROJECT%20WRITING%20GUIDELINES.pdf"><br> <input type="submit" value="READ NOW"></a>       
        </div>
         <div class="six">
           <br>
        <img src="images/python-basics-cover-900.75eb2f36588c.png" alt="">
          <h6> &#9733; &#9733; &#9733; &#9733; &#9733;<br> Python Basics</h6>
         <h5>By The realpython.com</h5>
          <br>
           <a href="pdf/python-basics-sample-chapters.pdf"><br><input type="submit" value="READ NOW"></a>           
        </div>
         <div class="seven">
             <br>
        <img src="images/power.jpeg" alt="">
          <h6> &#9733; &#9733; &#9733; &#9733; &#9733;<br> The 48 Laws of Power</h6>
         <h5>By Robert Greene</h5>
          <br>
          <a href="pdf/The+48+Laws+Of+Power.pdf"><br> <input type="submit" value="READ NOW"></a>
        </div>        
     </div>   
</body>
</html>
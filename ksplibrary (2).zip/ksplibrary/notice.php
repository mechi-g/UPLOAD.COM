<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="css/move.css">
<head>
    <meta charset="UTF-8">
     <link rel="shortcut icon" href="images/kpoly.jpeg">
    <title>KANO STATE POLYTECHNIC</title>
</head>
<body>
    <div class="box">
      <br>

       <h2> Don't Have an Account?</h2>
           <div class="seven">
             <br>
        <img src="images/login.png" alt="">
        </div>
    
       <button class="red"><a href="register.php"> Click To Register</a></button>
   
      <div class="now">  <a href="login.php"><br>Click To Login</a></div>
       
        <div class="noww">  <a href="homepage.php"><br>X</a></div>
        
    </div>
</body>
</html>